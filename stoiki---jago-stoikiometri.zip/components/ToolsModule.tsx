import React, { useState } from 'react';
import { balanceEquationAI } from '../services/geminiService';
import { EquationResponse } from '../types';
import { ArrowRight, Loader2, FlaskConical } from 'lucide-react';

const ToolsModule: React.FC = () => {
  const [inputEq, setInputEq] = useState('');
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<EquationResponse | null>(null);
  const [error, setError] = useState<string | null>(null);

  const handleBalance = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputEq.trim()) return;

    setLoading(true);
    setError(null);
    setResult(null);

    try {
      const data = await balanceEquationAI(inputEq);
      setResult(data);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Terjadi kesalahan");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto px-4 py-8">
      <div className="bg-white rounded-2xl shadow-xl overflow-hidden">
        <div className="bg-emerald-600 px-6 py-8 text-white text-center">
          <FlaskConical className="w-12 h-12 mx-auto mb-4 opacity-90" />
          <h2 className="text-3xl font-bold">Lab Kimia AI</h2>
          <p className="mt-2 text-emerald-100">Seimbangkan reaksi kimia dan hitung massa molar secara otomatis.</p>
        </div>

        <div className="p-8">
          <form onSubmit={handleBalance} className="mb-8">
            <label className="block text-sm font-medium text-slate-700 mb-2">
              Masukkan Persamaan Reaksi (contoh: H2 + O2 = H2O)
            </label>
            <div className="flex gap-2">
              <input
                type="text"
                value={inputEq}
                onChange={(e) => setInputEq(e.target.value)}
                placeholder="Misal: C3H8 + O2 -> CO2 + H2O"
                className="flex-1 rounded-lg border border-slate-300 px-4 py-3 focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 outline-none transition"
              />
              <button
                type="submit"
                disabled={loading || !inputEq}
                className="bg-emerald-600 text-white px-6 py-3 rounded-lg font-medium hover:bg-emerald-700 disabled:opacity-50 disabled:cursor-not-allowed transition flex items-center"
              >
                {loading ? <Loader2 className="w-5 h-5 animate-spin" /> : 'Proses'}
              </button>
            </div>
          </form>

          {error && (
            <div className="bg-red-50 border-l-4 border-red-500 p-4 mb-6">
              <p className="text-red-700">{error}</p>
            </div>
          )}

          {result && (
            <div className="space-y-6 animate-fadeIn">
              {/* Balanced Equation Card */}
              <div className="bg-slate-50 border border-slate-200 rounded-xl p-6">
                <h3 className="text-sm font-bold text-slate-500 uppercase tracking-wide mb-2">Persamaan Setara</h3>
                <div className="text-2xl md:text-3xl font-mono text-emerald-700 bg-white p-4 rounded-lg shadow-sm border border-emerald-100 overflow-x-auto">
                  {result.balancedEquation}
                </div>
              </div>

              <div className="grid md:grid-cols-2 gap-6">
                {/* Steps */}
                <div className="bg-white border border-slate-200 rounded-xl p-6 shadow-sm">
                  <h3 className="text-lg font-bold text-slate-800 mb-4 flex items-center">
                    <ArrowRight className="w-5 h-5 mr-2 text-emerald-500" />
                    Langkah Penyetaraan
                  </h3>
                  <ul className="space-y-3">
                    {result.steps.map((step, idx) => (
                      <li key={idx} className="flex items-start text-slate-600 text-sm">
                        <span className="bg-emerald-100 text-emerald-800 text-xs font-bold px-2 py-1 rounded-full mr-3 mt-0.5">
                          {idx + 1}
                        </span>
                        {step}
                      </li>
                    ))}
                  </ul>
                </div>

                {/* Molar Masses */}
                <div className="bg-white border border-slate-200 rounded-xl p-6 shadow-sm">
                   <h3 className="text-lg font-bold text-slate-800 mb-4">Massa Molar (Mr)</h3>
                   <div className="divide-y divide-slate-100">
                      {Object.entries(result.molarMasses).map(([compound, mass]) => (
                        <div key={compound} className="py-2 flex justify-between items-center">
                          <span className="font-mono text-slate-700 font-semibold">{compound}</span>
                          <span className="text-slate-500">{mass}</span>
                        </div>
                      ))}
                   </div>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default ToolsModule;
