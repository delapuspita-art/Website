import React, { useState } from 'react';
import { ChevronDown, ChevronUp, Database, Scale, TestTube } from 'lucide-react';

const topics = [
  {
    id: 1,
    title: "Konsep Mol",
    icon: <Database className="w-6 h-6 text-purple-500" />,
    content: (
      <div className="space-y-4">
        <p>
          <strong>Mol</strong> adalah satuan dasar dalam kimia untuk menyatakan jumlah zat. Satu mol zat mengandung jumlah partikel yang sama dengan jumlah atom dalam 12 gram isotop karbon-12.
        </p>
        <div className="bg-purple-50 p-4 rounded-lg border border-purple-100">
          <h4 className="font-bold text-purple-800">Bilangan Avogadro (L)</h4>
          <p className="text-2xl font-mono text-center my-2 text-purple-900">6,02 × 10²³</p>
          <p className="text-sm text-purple-700">Artinya, 1 mol air mengandung 6,02 × 10²³ molekul air.</p>
        </div>
        <p>Rumus dasar:</p>
        <ul className="list-disc list-inside text-slate-700 bg-white p-4 rounded shadow-sm">
          <li>n = jumlah partikel / L</li>
          <li>n = massa (gr) / Mr atau Ar</li>
        </ul>
      </div>
    )
  },
  {
    id: 2,
    title: "Massa Molar (Mr & Ar)",
    icon: <Scale className="w-6 h-6 text-emerald-500" />,
    content: (
      <div className="space-y-4">
        <p>
          <strong>Massa Atom Relatif (Ar)</strong> adalah perbandingan massa rata-rata satu atom unsur terhadap 1/12 massa atom C-12.
        </p>
        <p>
          <strong>Massa Molekul Relatif (Mr)</strong> adalah jumlah total Ar dari semua atom penyusun molekul tersebut.
        </p>
        <div className="bg-emerald-50 p-4 rounded-lg border border-emerald-100">
          <h4 className="font-bold text-emerald-800">Contoh: H₂O</h4>
          <p className="text-sm text-emerald-700 mt-2">
            Diketahui Ar H = 1, O = 16.<br/>
            Mr H₂O = (2 × Ar H) + (1 × Ar O)<br/>
            Mr H₂O = (2 × 1) + 16 = <strong>18 g/mol</strong>
          </p>
        </div>
      </div>
    )
  },
  {
    id: 3,
    title: "Persamaan Reaksi",
    icon: <TestTube className="w-6 h-6 text-blue-500" />,
    content: (
      <div className="space-y-4">
        <p>
          Persamaan reaksi menggambarkan perubahan kimia dari <strong>Pereaksi (Reaktan)</strong> menjadi <strong>Hasil Reaksi (Produk)</strong>.
        </p>
        <div className="bg-blue-50 p-4 rounded-lg border border-blue-100 flex items-center justify-center space-x-4">
           <div className="text-center">
             <span className="font-bold text-blue-900">Reaktan</span>
             <div className="text-sm text-blue-600">Sebelah Kiri</div>
           </div>
           <div className="text-2xl text-blue-400">→</div>
           <div className="text-center">
             <span className="font-bold text-blue-900">Produk</span>
             <div className="text-sm text-blue-600">Sebelah Kanan</div>
           </div>
        </div>
        <p className="text-slate-700">
          <strong>Hukum Kekekalan Massa (Lavoisier):</strong> Massa zat sebelum dan sesudah reaksi adalah sama. Oleh karena itu, jumlah atom tiap unsur di kiri dan kanan panah harus sama (Setara).
        </p>
      </div>
    )
  }
];

const LearnModule: React.FC = () => {
  const [openTopic, setOpenTopic] = useState<number | null>(1);

  const toggleTopic = (id: number) => {
    setOpenTopic(openTopic === id ? null : id);
  };

  return (
    <div className="max-w-4xl mx-auto px-4 py-8">
      <h2 className="text-3xl font-bold text-slate-800 mb-6 text-center">Materi Dasar Stoikiometri</h2>
      <div className="space-y-4">
        {topics.map((topic) => (
          <div key={topic.id} className="bg-white rounded-xl shadow-md overflow-hidden border border-slate-100">
            <button
              onClick={() => toggleTopic(topic.id)}
              className="w-full px-6 py-4 flex items-center justify-between bg-slate-50 hover:bg-slate-100 transition-colors focus:outline-none"
            >
              <div className="flex items-center space-x-3">
                {topic.icon}
                <span className="font-semibold text-lg text-slate-800">{topic.title}</span>
              </div>
              {openTopic === topic.id ? (
                <ChevronUp className="w-5 h-5 text-slate-500" />
              ) : (
                <ChevronDown className="w-5 h-5 text-slate-500" />
              )}
            </button>
            {openTopic === topic.id && (
              <div className="px-6 py-6 animate-fadeIn">
                <div className="prose prose-slate max-w-none text-slate-600 leading-relaxed">
                  {topic.content}
                </div>
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
};

export default LearnModule;
