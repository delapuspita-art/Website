import React from 'react';
import { ViewState } from '../types';
import { Beaker, BookOpen, MessageCircle, Calculator, BrainCircuit } from 'lucide-react';

interface NavbarProps {
  currentView: ViewState;
  setView: (view: ViewState) => void;
}

const Navbar: React.FC<NavbarProps> = ({ currentView, setView }) => {
  const navItems = [
    { id: 'home', label: 'Beranda', icon: <Beaker className="w-5 h-5" /> },
    { id: 'learn', label: 'Materi', icon: <BookOpen className="w-5 h-5" /> },
    { id: 'tools', label: 'Alat', icon: <Calculator className="w-5 h-5" /> },
    { id: 'tutor', label: 'Tutor AI', icon: <MessageCircle className="w-5 h-5" /> },
    { id: 'quiz', label: 'Kuis', icon: <BrainCircuit className="w-5 h-5" /> },
  ];

  return (
    <nav className="bg-white border-b border-slate-200 sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16">
          <div className="flex items-center cursor-pointer" onClick={() => setView('home')}>
            <div className="bg-emerald-600 p-2 rounded-lg mr-2">
              <Beaker className="w-6 h-6 text-white" />
            </div>
            <span className="text-xl font-bold text-slate-800 tracking-tight">StoiKi</span>
          </div>
          
          <div className="hidden md:flex space-x-1">
            {navItems.map((item) => (
              <button
                key={item.id}
                onClick={() => setView(item.id as ViewState)}
                className={`flex items-center px-4 py-2 rounded-md text-sm font-medium transition-colors ${
                  currentView === item.id
                    ? 'bg-emerald-50 text-emerald-700'
                    : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900'
                }`}
              >
                <span className="mr-2">{item.icon}</span>
                {item.label}
              </button>
            ))}
          </div>

          {/* Mobile menu button could go here, simplifying for this output */}
          <div className="flex md:hidden items-center">
            <div className="flex space-x-4">
              {navItems.slice(1).map(item => (
                 <button key={item.id} onClick={() => setView(item.id as ViewState)} className={`p-2 rounded-md ${currentView === item.id ? 'text-emerald-600 bg-emerald-50' : 'text-slate-500'}`}>
                    {item.icon}
                 </button>
              ))}
            </div>
          </div>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;
